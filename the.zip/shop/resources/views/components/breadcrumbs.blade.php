<div class="breadcrumbs">
    <div class="breadcrumbs-container container">
        <div>
            {{ $slot }}
        </div>
        <div>
            @include('partials.search')
        </div>
    </div>
</div> <!-- end breadcrumbs -->
